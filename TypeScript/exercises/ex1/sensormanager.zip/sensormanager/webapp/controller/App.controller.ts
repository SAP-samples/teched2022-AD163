import Controller from "sap/ui/core/mvc/Controller";

/**
 * @namespace keepcool.sensormanager.controller
 */
export default class App extends Controller {

    public onInit(): void {

    }
}