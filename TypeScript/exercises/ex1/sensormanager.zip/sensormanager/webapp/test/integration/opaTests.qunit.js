/* global QUnit */

sap.ui.require(["keepcool/sensormanager/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
