sap.ui.define([
	"keepcool/sensormanager/test/unit/controller/App.controller"
], function () {
	"use strict";
});
